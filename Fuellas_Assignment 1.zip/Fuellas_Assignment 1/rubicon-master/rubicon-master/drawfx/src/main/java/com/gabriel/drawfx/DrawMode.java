package com.gabriel.drawfx;

public enum DrawMode {
    Idle,
    MousePressed,
    MouseReleased,
}
