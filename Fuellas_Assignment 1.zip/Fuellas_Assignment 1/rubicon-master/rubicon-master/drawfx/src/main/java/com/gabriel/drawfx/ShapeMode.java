package com.gabriel.drawfx;

public enum ShapeMode {
    Line,
    Rectangle,
    Ellipse,
}
